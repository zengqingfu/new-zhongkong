var express = require('express');
var app = express()
var http = require('http').Server(app);
const net = require('net');
const udp = require('dgram');
const os = require("os");
const child = require('child_process')
const networkInterfaces = os.networkInterfaces();
//创建 udp server
const udp_server = udp.createSocket('udp4');
//创建 osc server
var osc = require('node-osc');
var oscServer
var oscClient
var port = 7858 // 本机端口

/**
 * 获取当前机器的ip地址
 */
function getIpAddress() {
    let ifaces = os.networkInterfaces()
    for (let dev in ifaces) {
        let iface = ifaces[dev]
        for (let i = 0; i < iface.length; i++) {
            let { family, address, internal } = iface[i]
            if (family === 'IPv4' && address !== '127.0.0.1' && !internal) {
                udp_server.bind(port, address); // 绑定端口
                udp_server.on('listening', function () {
                    console.log('udp server linstening '+port);
                })
                oscServer = new osc.Server(7001, address);  // 主机osc ip
                oscClient = new osc.Client(address, 7000);  // 发送osc ip
                return address
            }
        }
    }
}
console.log(getIpAddress())

//错误处理
udp_server.on('error', function (err) {
    console.log('some error on udp server.')
    udp_server.close();
})

//udp接收消息
udp_server.on('message', function (msg, rinfo) {
    let strmsg = msg.toString(); //parseInt()
    let infodataarr
     if (strmsg.indexOf('-') > 0) {
        infodataarr = strmsg.split('-')
        oscClient.send('/composition/layers/'+infodataarr[0]+'/clips/'+infodataarr[1]+'/connect', 0);
        console.log('指定行例',infodataarr);
    } else if (strmsg.indexOf('~') > 0) {
        infodataarr = strmsg.split('~')
        oscClient.send('/composition/columns/'+infodataarr[0]+'/connect', 0);
        console.log('指定单例',infodataarr); 
    } else if (strmsg.indexOf('replay') > 0) {
        oscClient.send('/composition/selectedclip/transport/position', 0);
        console.log('重播')
    } else if (strmsg.indexOf('play') > 0) {
        oscClient.send('/composition/selectedclip/transport/position/behaviour/playdirection', 1);
        console.log('播放'); 
    } else if (strmsg.indexOf('pause') > 0) {
        oscClient.send('/composition/selectedclip/transport/position/behaviour/playdirection', 2);
        console.log('暂停'); 
    } else if (strmsg.indexOf('volume') > 0) {
        infodataarr = strmsg.split('volume')
        console.log('音量',infodataarr); 
    } else if (strmsg.indexOf('restart') > 0) {
        console.log('重启'); 
    } else if (strmsg.indexOf('off') > 0) {
        console.log('关机'); 
    }
    console.log(strmsg)
})